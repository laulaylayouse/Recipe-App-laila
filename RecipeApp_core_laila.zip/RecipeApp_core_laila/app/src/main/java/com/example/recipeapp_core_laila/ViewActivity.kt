package com.example.recipeapp_core_laila


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewActivity : AppCompatActivity() {
    var myRecipeList = arrayListOf<Recipe_Details.Recipe>()
    lateinit var Card_View: CardView
    lateinit var RecyclerView : RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)

        supportActionBar?.hide()

        RecyclerView = findViewById(R.id.RecyclerView)
        RecyclerView.adapter =Adapter(myRecipeList)
        RecyclerView.layoutManager = LinearLayoutManager(this)

        getRecipes()

    }


    private fun getRecipes(){
        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)

        apiInterface?.getRecipe()?.enqueue(object : Callback<List<Recipe_Details.Recipe>> {
            override fun onResponse(
                call: Call<List<Recipe_Details.Recipe>>,
                response: Response<List<Recipe_Details.Recipe>>
            ) {

                val resource = response.body()!!
                for ( i in resource){

                    var Title = i.title.toString()
                    var Author = i.author.toString()
                    var ingredients = i.ingredients.toString()
                    var instructions = i.instructions.toString()
                    myRecipeList.add(Recipe_Details.Recipe(Title,Author, ingredients, instructions))

                }
                RecyclerView.adapter?.notifyDataSetChanged()

            }

            override fun onFailure(call: Call<List<Recipe_Details.Recipe>>, t: Throwable) {
                call.cancel()
            }
        })

    }
}