package com.example.recipeapp_core_laila

import android.app.AlertDialog
import android.content.DialogInterface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_row.view.*

class Adapter ( private val messages: List<Recipe_Details.Recipe>):
    RecyclerView.Adapter<Adapter.ItemViewHolder>(){
    class ItemViewHolder (itemView: View): RecyclerView.ViewHolder(itemView){}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_row,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        var message = messages[position]

        holder.itemView.apply {

            TextView_Title.text = "Title: ${message.title}"
            TextView_Author.text = "Author: ${message.author}"
            Card_View.setOnClickListener {

                var alertDialog = AlertDialog.Builder(context, R.style.AlertDialogCustom)

                val dialogBuilder = AlertDialog.Builder(context)
                dialogBuilder.setMessage("Title: ${message.title}\n" +
                        "Author: ${message.author}\n" +
                        "Instructions: ${message.instructions}\n" +
                        "Ingredients: ${message.ingredients}")
                    .setPositiveButton("OK", DialogInterface.OnClickListener {
                            dialog, id -> dialog.cancel()
                    })

                val alert = dialogBuilder.create()
                alert.setTitle("Detailed" )
                alert.show()

            }
        }
    }

    override fun getItemCount()= messages.size
}

