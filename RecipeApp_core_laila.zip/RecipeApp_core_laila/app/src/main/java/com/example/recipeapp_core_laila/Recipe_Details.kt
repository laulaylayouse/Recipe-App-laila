package com.example.recipeapp_core_laila

import com.google.gson.annotations.SerializedName

class Recipe_Details {

    var data: List<Recipe>? = null

    class Recipe {

        @SerializedName("pk")
        var id: Int? = null


        @SerializedName("title")
        var title: String? = null

        @SerializedName("author")
        var author: String? = null

        constructor(title: String?, author: String?, ingredients: String?, instructions: String?) {
            this.title = title
            this.author = author
            this.ingredients = ingredients
            this.instructions = instructions
        }

        @SerializedName("ingredients")
        var ingredients: String? = null

        @SerializedName("instructions")
        var instructions: String? = null
    }


}