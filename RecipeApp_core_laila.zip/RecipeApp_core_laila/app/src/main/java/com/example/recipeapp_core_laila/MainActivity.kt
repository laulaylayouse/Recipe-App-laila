package com.example.recipeapp_core_laila

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    lateinit var EditText_Title: EditText
    lateinit var EditText_Author: EditText
    lateinit var EditText_Ingredents: EditText
    lateinit var EditText_Instruction: EditText

    lateinit var Button_Save: Button
    lateinit var Button_View: Button

    var title = ""
    var author = ""
    var ingredients = ""
    var instructions = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.hide()

        this.currentFocus?.let { view ->
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.hideSoftInputFromWindow(view.windowToken, 0)
        }

        EditText_Title = findViewById(R.id.EditText_Title)
        EditText_Author = findViewById(R.id.EditText_Author)
        EditText_Ingredents = findViewById(R.id.EditText_Ingredents)
        EditText_Instruction = findViewById(R.id.EditText_Instruction)

        Button_Save = findViewById(R.id.Button_Save)
        Button_Save.setOnClickListener {

            title = EditText_Title.text.toString()
            author = EditText_Author.text.toString()
            ingredients = EditText_Ingredents.text.toString()
            instructions = EditText_Instruction.text.toString()

            if (title.isNotEmpty() &&
                author.isNotEmpty() &&
                ingredients.isNotEmpty() &&
                instructions.isNotEmpty())
                {
                save_Recipe()
                Toast.makeText(this, "New Recipe is added!!", Toast.LENGTH_LONG).show()
            }
            else
            {
                Toast.makeText(this, "Please Enter a Recipe Correctly", Toast.LENGTH_LONG).show()
            }

            EditText_Title.setText("")
            EditText_Author.setText("")
            EditText_Ingredents.setText("")
            EditText_Instruction.setText("")

        }

        Button_View = findViewById(R.id.Button_View)
        Button_View.setOnClickListener {
            val intent = Intent(this, ViewActivity::class.java)
            startActivity(intent) }

    }

    private fun save_Recipe() {
        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)


        apiInterface?.addRecipe(Recipe_Details.Recipe(title , author , ingredients , instructions))?.enqueue(object :
            Callback<List<Recipe_Details.Recipe>> {

            override fun onFailure(call: Call<List<Recipe_Details.Recipe>>, t: Throwable) {
                call.cancel()
            }

            override fun onResponse(
                call: Call<List<Recipe_Details.Recipe>>,
                response: Response<List<Recipe_Details.Recipe>>
            ) {

                response.body()!!
            }

        }
        )
    }
}